<?php

$greeting = 'Hi';